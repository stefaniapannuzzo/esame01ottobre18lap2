import React from 'react';
import {View,Text,StyleSheet,TouchableHighlight,Image,Button} from 'react-native';

const TINT_COLOR = 'rgb(4, 159, 239)';



export default class CommentsScreen extends React.Component {
  state = {
    Lista: []
    };


  componentWillMount() { 
    const Params = this.props.navigation.state.params.CurrentElem;
    this.setState({Lista : Params});
  }

  render() {
    return (
      <View style={styles.container}>
        <Image
          style={{ width: '100%', height: '50%' }}
          source={{ uri: this.state.Lista.img }}
        />
        <View>
          <View style={styles.titleView}>
            <Text style= {styles.id}> {this.state.Lista.id} </Text>
            <Text style = {styles.author}> {this.state.Lista.author} </Text>
          </View>
          <View style={styles.counter}>
            
          </View>
      </View>
    </View>
    );
  }
}

CommentsScreen.navigationOptions = ({ navigation }) => {
  return {
    title: 'Comments',
    headerStyle: {
      backgroundColor: TINT_COLOR,
    },
    headerTintColor: 'white',
    headerRight: null,
  };
};


const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'flex-start',
    alignItems: 'stretch',
    padding: 20,
  },
  titleView: {
    height : 20,
    width : "100%",
    flexDirection : "row",
  }

});