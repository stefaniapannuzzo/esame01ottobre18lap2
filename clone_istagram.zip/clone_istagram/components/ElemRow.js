import React from 'react';
import {View,Text,StyleSheet,TouchableHighlight,Image,} from'react-native';

export default class ElemRow extends React.Component {
  render() {
    return ( 
      <TouchableHighlight onPress={this.props.onDetails}>
        <View style={styles.container}>
          <Image
            style={{ height: 50, width: 50 }}
            source={{ uri: 'http://picsum.photos/600/600?image={1'}}
          />

          <View style={styles.viewText}>
            <Text style={styles.title}>{this.props.data.nome}</Text>
            <Text style={styles.subtitle}>{this.props.data.cognome}</Text>
            <Text style={styles.price}>{this.props.data.commenti}</Text>
            <Text style={styles.price}>{this.props.data.immagine}</Text>
          </View>
        </View>
      </TouchableHighlight>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    borderBottomWidth: 1,
    borderColor: 'lightgray',
    height: 200,
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'center',
    padding: 10,
  },
  viewText: {
    height: 140,
    marginLeft: 10,
    marginRight : 10,
    padding: 10,
  },
  title: {
    fontSize: 20,
    fontWeight: '500',
  },
  subtitle: {
    color: 'black',
  },
 
});
