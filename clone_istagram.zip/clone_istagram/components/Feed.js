import React from "react";
import { StyleSheet, Text, View, ScrollView, TouchableOpacity,  FlatList } from "react-native";
import { createStackNavigator, TabNavigator } from "react-navigation";


import ElemRow from './ElemRow';
import CommentsScreen from './CommentsScreen';
const TINT_COLOR = 'rgb(4, 159, 239)';


export default class Feed extends React.Component {
  state = {
    Elementi: [], 
  };


  componentDidMount(){  
    this.makeRemoteRequest();
  }

  makeRemoteRequest = () => {
    const MyElementi = 'http://unsplash.it/list';
    fetch(MyElementi)
      .then(response => response.json())
        .then(jsonResponse => {
          let array = jsonResponse.data;
          this.setState({ Elementi : array})
        })
  };

  _toDetail = (item) => {
    this.props.navigation.navigate("Comments" , {CurrentElem : item}) 
 }

  renderRow = ({ item }) => (
    <ElemRow 
      data={item} 
      onDetails={() => this._toDetail(item)}/>
  );

  keyExtractor = (item, index) => {
    return String(index);
  };


  render() {
    return ( 
      <View style={styles.container}>  
        <ScrollView>
        <FlatList
          data={this.state.Elementi}
          renderItem={this.renderRow}
          keyExtractor={this.keyExtractor}
        />
        </ScrollView>
      </View>
    );
  }
  }


Feed.navigationOptions = ({ navigation }) => {
  return {
    title: 'Home CloneGram',
    headerStyle: {
      backgroundColor: TINT_COLOR,
    },
    headerTintColor: 'white',
    
  };
};



const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: "column",
    paddingTop: 40,
    backgroundColor: '#fff',
    alignItems: 'stretch',
    justifyContent: 'center',
  },
});
  