import React, { Component } from 'react';
import { StyleSheet, Text, View, ScrollView, FlatList, Button, TouchableHighlight, Image } from "react-native";
import { createStackNavigator, TabNavigator } from "react-navigation";

const TINT_COLOR = 'rgb(4, 159, 239)';

import Feed from './components/Feed';
import CommentScreen from './components/CommentScreen';


const Clone= createStackNavigator({
  Clone: {
    screen: Feed, //menùscreen
    navigationOptions: {
      title: "Home" //Home-Menù
    }
  },
  Details: {
    screen: CommentScreen,
    navigationOptions: {
      title: "Detail"
    }
  },
})

const MainNav = TabNavigator({
  
  Clone: { 
    screen: Feed 
  },
});

export default class App extends React.Component {
  render() {
    return <MainNav />;
      
    
  }
} 